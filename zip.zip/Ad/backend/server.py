from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from typing import List
from models import (
    Post, PostCreate, PostUpdate,
    Comment, CommentCreate,
    Newsletter, NewsletterCreate,
    Contact, ContactCreate
)
from seed_data import initial_posts


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# ================= POSTS ROUTES =================

@api_router.get("/posts", response_model=List[Post])
async def get_posts():
    """Listar todos os posts"""
    posts = await db.posts.find({}, {"_id": 0}).to_list(1000)
    return [Post(**post) for post in posts]


@api_router.get("/posts/{slug}", response_model=Post)
async def get_post_by_slug(slug: str):
    """Buscar post por slug"""
    post = await db.posts.find_one({"slug": slug}, {"_id": 0})
    if not post:
        raise HTTPException(status_code=404, detail="Post não encontrado")
    return Post(**post)


@api_router.post("/posts", response_model=Post)
async def create_post(post_data: PostCreate):
    """Criar novo post"""
    # Check if slug already exists
    existing = await db.posts.find_one({"slug": post_data.slug})
    if existing:
        raise HTTPException(status_code=400, detail="Slug já existe")
    
    post = Post(**post_data.dict())
    await db.posts.insert_one(post.dict())
    return post


@api_router.put("/posts/{slug}", response_model=Post)
async def update_post(slug: str, post_data: PostUpdate):
    """Atualizar post"""
    existing = await db.posts.find_one({"slug": slug})
    if not existing:
        raise HTTPException(status_code=404, detail="Post não encontrado")
    
    # Update only provided fields
    update_data = {k: v for k, v in post_data.dict().items() if v is not None}
    
    if update_data:
        await db.posts.update_one({"slug": slug}, {"$set": update_data})
    
    updated_post = await db.posts.find_one({"slug": slug}, {"_id": 0})
    return Post(**updated_post)


@api_router.delete("/posts/{slug}")
async def delete_post(slug: str):
    """Deletar post"""
    result = await db.posts.delete_one({"slug": slug})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Post não encontrado")
    
    # Delete associated comments
    await db.comments.delete_many({"postId": slug})
    
    return {"message": "Post deletado com sucesso"}


@api_router.get("/posts/category/{category_slug}", response_model=List[Post])
async def get_posts_by_category(category_slug: str):
    """Listar posts por categoria"""
    posts = await db.posts.find({"category": category_slug}, {"_id": 0}).to_list(1000)
    return [Post(**post) for post in posts]


# ================= COMMENTS ROUTES =================

@api_router.get("/comments/{post_id}", response_model=List[Comment])
async def get_comments_by_post(post_id: str):
    """Listar comentários de um post"""
    comments = await db.comments.find({"postId": post_id}, {"_id": 0}).to_list(1000)
    return [Comment(**comment) for comment in comments]


@api_router.post("/comments", response_model=Comment)
async def create_comment(comment_data: CommentCreate):
    """Criar comentário"""
    comment = Comment(**comment_data.dict())
    await db.comments.insert_one(comment.dict())
    return comment


# ================= NEWSLETTER ROUTES =================

@api_router.post("/newsletter")
async def subscribe_newsletter(newsletter_data: NewsletterCreate):
    """Inscrever email na newsletter"""
    # Check if email already exists
    existing = await db.newsletter.find_one({"email": newsletter_data.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email já cadastrado")
    
    newsletter = Newsletter(**newsletter_data.dict())
    await db.newsletter.insert_one(newsletter.dict())
    return {"message": "Inscrito com sucesso"}


# ================= CONTACT ROUTES =================

@api_router.post("/contact")
async def send_contact(contact_data: ContactCreate):
    """Enviar mensagem de contato"""
    contact = Contact(**contact_data.dict())
    await db.contacts.insert_one(contact.dict())
    return {"message": "Mensagem enviada com sucesso"}


# ================= SEED DATA ROUTE =================

@api_router.post("/seed")
async def seed_database():
    """Popular banco de dados com posts iniciais"""
    # Check if posts already exist
    count = await db.posts.count_documents({})
    if count > 0:
        return {"message": f"Banco já possui {count} posts"}
    
    # Insert initial posts
    for post_data in initial_posts:
        post = Post(**post_data)
        await db.posts.insert_one(post.dict())
    
    return {"message": f"{len(initial_posts)} posts inseridos com sucesso"}


# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()