from pydantic import BaseModel, Field, EmailStr
from typing import Optional
from datetime import datetime
import uuid


class Post(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    slug: str
    excerpt: str
    content: str
    category: str
    categoryName: str
    author: str = "Equipe Cashback Brasil"
    date: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    readTime: str
    image: str


class PostCreate(BaseModel):
    title: str
    slug: str
    excerpt: str
    content: str
    category: str
    categoryName: str
    image: str
    readTime: str


class PostUpdate(BaseModel):
    title: Optional[str] = None
    slug: Optional[str] = None
    excerpt: Optional[str] = None
    content: Optional[str] = None
    category: Optional[str] = None
    categoryName: Optional[str] = None
    image: Optional[str] = None
    readTime: Optional[str] = None


class Comment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    postId: str
    author: str
    email: EmailStr
    content: str
    date: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    approved: bool = True


class CommentCreate(BaseModel):
    postId: str
    author: str
    email: EmailStr
    content: str


class Newsletter(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    subscribedAt: str = Field(default_factory=lambda: datetime.utcnow().isoformat())


class NewsletterCreate(BaseModel):
    email: EmailStr


class Contact(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: EmailStr
    subject: str
    message: str
    sentAt: str = Field(default_factory=lambda: datetime.utcnow().isoformat())


class ContactCreate(BaseModel):
    name: str
    email: EmailStr
    subject: str
    message: str
