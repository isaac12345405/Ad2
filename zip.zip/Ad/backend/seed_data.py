# Dados iniciais para popular o banco de dados

initial_posts = [
    {
        "title": "Como Funciona o Cashback: Guia Completo para Iniciantes",
        "slug": "como-funciona-cashback-guia-completo",
        "excerpt": "Descubra como o sistema de cashback pode te ajudar a economizar dinheiro em todas as suas compras online e offline.",
        "content": """<p>O cashback é uma forma inteligente de recuperar parte do dinheiro gasto em compras. Basicamente, você recebe de volta uma porcentagem do valor que gastou.</p>

<h2>O Que É Cashback?</h2>
<p>Cashback significa "dinheiro de volta" em inglês. É um sistema de recompensas onde você recebe uma porcentagem do valor gasto em compras de volta para sua conta.</p>

<h2>Como Funciona na Prática?</h2>
<p>1. Você se cadastra em uma plataforma de cashback<br/>
2. Acessa a loja através do link da plataforma<br/>
3. Faz sua compra normalmente<br/>
4. Recebe uma porcentagem de volta em sua conta</p>

<h2>Vantagens do Cashback</h2>
<ul>
<li>Economia garantida em todas as compras</li>
<li>Funciona com lojas que você já usa</li>
<li>Dinheiro real de volta</li>
<li>Sem custos ou taxas</li>
</ul>""",
        "category": "como-funciona",
        "categoryName": "Como Funciona",
        "author": "Equipe Cashback Brasil",
        "readTime": "5 min",
        "image": "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&q=80"
    },
    {
        "title": "Top 10 Melhores Apps de Cashback em 2025",
        "slug": "top-10-melhores-apps-cashback-2025",
        "excerpt": "Conheça os aplicativos de cashback mais vantajosos do mercado brasileiro e escolha o melhor para você.",
        "content": """<p>Selecionamos os melhores aplicativos de cashback disponíveis no Brasil em 2025.</p>

<h2>1. Méliuz</h2>
<p>O Méliuz é um dos apps mais populares, oferecendo cashback em mais de 2.000 lojas parceiras. Com taxas que variam de 1% a 30%, é uma ótima opção para quem compra online.</p>

<h2>2. Picpay</h2>
<p>Além de carteira digital, o PicPay oferece cashback em diversos estabelecimentos físicos e online.</p>

<h2>3. Ame Digital</h2>
<p>A Ame oferece cashback instantâneo em compras e também tem parcerias com grandes redes.</p>

<h2>Como Escolher o Melhor App</h2>
<ul>
<li>Verifique as lojas parceiras</li>
<li>Compare as taxas de cashback</li>
<li>Analise as formas de resgate</li>
<li>Leia avaliações de outros usuários</li>
</ul>""",
        "category": "melhores-apps",
        "categoryName": "Melhores Apps",
        "author": "Equipe Cashback Brasil",
        "readTime": "7 min",
        "image": "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&q=80"
    },
    {
        "title": "7 Dicas Para Maximizar Seu Cashback",
        "slug": "7-dicas-maximizar-cashback",
        "excerpt": "Aprenda estratégias comprovadas para aumentar seus ganhos com cashback e economizar ainda mais.",
        "content": """<p>Usar cashback é bom, mas usar com estratégia é ainda melhor. Veja nossas dicas para ganhar mais.</p>

<h2>1. Use Múltiplas Plataformas</h2>
<p>Compare as taxas entre diferentes apps antes de fazer uma compra. Uma loja pode oferecer 5% em um app e 8% em outro.</p>

<h2>2. Aproveite Promoções Especiais</h2>
<p>Fique atento às campanhas de cashback turbinado, que podem chegar a 50% ou mais em datas especiais.</p>

<h2>3. Combine com Cupons de Desconto</h2>
<p>Muitas plataformas permitem usar cupons de desconto junto com cashback, multiplicando sua economia.</p>

<h2>4. Ative Notificações</h2>
<p>Receba alertas sobre ofertas especiais e não perca nenhuma oportunidade de ganhar mais.</p>

<h2>5. Indique Amigos</h2>
<p>Muitos apps oferecem bônus por indicação. Compartilhe seu código e ganhe ainda mais.</p>""",
        "category": "dicas",
        "categoryName": "Dicas",
        "author": "Equipe Cashback Brasil",
        "readTime": "6 min",
        "image": "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=800&q=80"
    },
    {
        "title": "Cashback em Supermercados: Vale a Pena?",
        "slug": "cashback-supermercados-vale-pena",
        "excerpt": "Descubra como usar cashback nas compras do supermercado e se realmente compensa para o dia a dia.",
        "content": """<p>O cashback não serve apenas para compras online. Veja como usar no supermercado.</p>

<h2>Como Funciona no Supermercado</h2>
<p>Diversos apps oferecem cashback em compras de supermercado através de cartões vinculados ou QR codes.</p>

<h2>Principais Opções</h2>
<p>Apps como PicPay, Ame e bancos digitais oferecem cashback em redes de supermercados parceiras.</p>

<h2>Vale a Pena?</h2>
<p>Sim! Mesmo com taxas menores (geralmente 1% a 3%), como você compra no supermercado regularmente, o valor acumulado ao final do mês faz diferença.</p>

<h2>Dica Extra</h2>
<p>Alguns apps oferecem cashback maior em produtos específicos. Fique atento às ofertas da semana.</p>""",
        "category": "dicas",
        "categoryName": "Dicas",
        "author": "Equipe Cashback Brasil",
        "readTime": "4 min",
        "image": "https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&q=80"
    },
    {
        "title": "Erros Comuns ao Usar Cashback e Como Evitá-los",
        "slug": "erros-comuns-cashback-como-evitar",
        "excerpt": "Evite os erros mais comuns que podem fazer você perder dinheiro ao usar plataformas de cashback.",
        "content": """<p>Muitas pessoas perdem cashback por erros simples. Veja como evitá-los.</p>

<h2>Erro 1: Não Usar o Link da Plataforma</h2>
<p>Se você acessar a loja diretamente, o cashback não é rastreado. Sempre acesse através do app ou site de cashback.</p>

<h2>Erro 2: Usar Bloqueadores de Anúncios</h2>
<p>Extensões de bloqueio podem interferir no rastreamento. Desative-as ao fazer compras com cashback.</p>

<h2>Erro 3: Não Ler as Regras</h2>
<p>Cada loja tem suas condições. Alguns produtos podem não dar direito a cashback.</p>

<h2>Erro 4: Esquecer de Resgatar</h2>
<p>Muitas plataformas têm prazo de validade para o cashback acumulado. Fique atento!</p>

<h2>Erro 5: Não Reclamar Quando Não Recebe</h2>
<p>Se o cashback não aparecer, entre em contato com o suporte. Tenha sempre o comprovante da compra.</p>""",
        "category": "como-funciona",
        "categoryName": "Como Funciona",
        "author": "Equipe Cashback Brasil",
        "readTime": "5 min",
        "image": "https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf?w=800&q=80"
    }
]
