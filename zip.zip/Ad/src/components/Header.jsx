import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Menu, X } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/busca?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">CB</span>
            </div>
            <span className="text-xl font-bold text-gray-900">Cashback Brasil</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">
              Home
            </Link>
            <Link to="/categoria/como-funciona" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">
              Como Funciona
            </Link>
            <Link to="/categoria/melhores-apps" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">
              Melhores Apps
            </Link>
            <Link to="/categoria/dicas" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">
              Dicas
            </Link>
            <Link to="/sobre" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">
              Sobre
            </Link>
            <Link to="/contato" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">
              Contato
            </Link>
          </nav>

          {/* Search Bar */}
          <div className="hidden md:flex items-center">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Buscar artigos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64 pl-4 pr-10"
              />
              <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-emerald-600">
                <Search className="w-5 h-5" />
              </button>
            </form>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-gray-700"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-4">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Buscar artigos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-4 pr-10"
              />
              <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                <Search className="w-5 h-5" />
              </button>
            </form>
            <nav className="flex flex-col space-y-3">
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="text-gray-700 hover:text-emerald-600 font-medium">
                Home
              </Link>
              <Link to="/categoria/como-funciona" onClick={() => setIsMenuOpen(false)} className="text-gray-700 hover:text-emerald-600 font-medium">
                Como Funciona
              </Link>
              <Link to="/categoria/melhores-apps" onClick={() => setIsMenuOpen(false)} className="text-gray-700 hover:text-emerald-600 font-medium">
                Melhores Apps
              </Link>
              <Link to="/categoria/dicas" onClick={() => setIsMenuOpen(false)} className="text-gray-700 hover:text-emerald-600 font-medium">
                Dicas
              </Link>
              <Link to="/sobre" onClick={() => setIsMenuOpen(false)} className="text-gray-700 hover:text-emerald-600 font-medium">
                Sobre
              </Link>
              <Link to="/contato" onClick={() => setIsMenuOpen(false)} className="text-gray-700 hover:text-emerald-600 font-medium">
                Contato
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;