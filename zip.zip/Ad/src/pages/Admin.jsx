import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { useToast } from '../hooks/use-toast';
import { posts as mockPosts, categories } from '../mockData';
import { FileEdit, Trash2, Plus } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';

const Admin = () => {
  const [posts, setPosts] = useState(mockPosts);
  const [isEditing, setIsEditing] = useState(false);
  const [currentPost, setCurrentPost] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    excerpt: '',
    content: '',
    category: '',
    image: '',
    readTime: ''
  });
  const { toast } = useToast();

  const handleEdit = (post) => {
    setIsEditing(true);
    setCurrentPost(post);
    setFormData({
      title: post.title,
      slug: post.slug,
      excerpt: post.excerpt,
      content: post.content.replace(/<[^>]*>/g, ''),
      category: post.category,
      image: post.image,
      readTime: post.readTime
    });
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir este post?')) {
      setPosts(posts.filter(p => p.id !== id));
      toast({
        title: 'Post excluído!',
        description: 'O post foi removido com sucesso.',
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (isEditing && currentPost) {
      // Update existing post
      const updatedPosts = posts.map(p => {
        if (p.id === currentPost.id) {
          return {
            ...p,
            ...formData,
            categoryName: categories.find(c => c.slug === formData.category)?.name || '',
            content: `<p>${formData.content.split('\n\n').join('</p><p>')}</p>`
          };
        }
        return p;
      });
      setPosts(updatedPosts);
      toast({
        title: 'Post atualizado!',
        description: 'As alterações foram salvas com sucesso.',
      });
    } else {
      // Create new post
      const newPost = {
        id: String(posts.length + 1),
        ...formData,
        categoryName: categories.find(c => c.slug === formData.category)?.name || '',
        author: 'Equipe Cashback Brasil',
        date: new Date().toISOString().split('T')[0],
        content: `<p>${formData.content.split('\n\n').join('</p><p>')}</p>`
      };
      setPosts([newPost, ...posts]);
      toast({
        title: 'Post criado!',
        description: 'O novo post foi publicado com sucesso.',
      });
    }

    // Reset form
    setIsEditing(false);
    setCurrentPost(null);
    setFormData({
      title: '',
      slug: '',
      excerpt: '',
      content: '',
      category: '',
      image: '',
      readTime: ''
    });
  };

  const handleCancel = () => {
    setIsEditing(false);
    setCurrentPost(null);
    setFormData({
      title: '',
      slug: '',
      excerpt: '',
      content: '',
      category: '',
      image: '',
      readTime: ''
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Painel Administrativo</h1>
          <p className="text-xl text-gray-600">Gerencie os posts do blog</p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Post Form */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>{isEditing ? 'Editar Post' : 'Criar Novo Post'}</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="title">Título</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="slug">Slug (URL)</Label>
                    <Input
                      id="slug"
                      value={formData.slug}
                      onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="category">Categoria</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat.id} value={cat.slug}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="excerpt">Resumo</Label>
                    <Textarea
                      id="excerpt"
                      value={formData.excerpt}
                      onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
                      rows={3}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="content">Conteúdo</Label>
                    <Textarea
                      id="content"
                      value={formData.content}
                      onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                      rows={8}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="image">URL da Imagem</Label>
                    <Input
                      id="image"
                      value={formData.image}
                      onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="readTime">Tempo de Leitura</Label>
                    <Input
                      id="readTime"
                      placeholder="ex: 5 min"
                      value={formData.readTime}
                      onChange={(e) => setFormData({ ...formData, readTime: e.target.value })}
                      required
                    />
                  </div>

                  <div className="flex space-x-2">
                    <Button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-700">
                      {isEditing ? 'Atualizar' : 'Criar Post'}
                    </Button>
                    {isEditing && (
                      <Button type="button" variant="outline" onClick={handleCancel}>
                        Cancelar
                      </Button>
                    )}
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Posts List */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Posts Publicados ({posts.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {posts.map((post) => (
                    <div
                      key={post.id}
                      className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-2">{post.title}</h3>
                          <p className="text-sm text-gray-600 mb-2">{post.excerpt}</p>
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded">
                              {post.categoryName}
                            </span>
                            <span>{new Date(post.date).toLocaleDateString('pt-BR')}</span>
                            <span>{post.readTime}</span>
                          </div>
                        </div>
                        <div className="flex flex-col space-y-2 ml-4">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(post)}
                            className="text-blue-600 hover:bg-blue-50"
                          >
                            <FileEdit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDelete(post.id)}
                            className="text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Admin;