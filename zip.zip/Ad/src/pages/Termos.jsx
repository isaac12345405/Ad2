import React from 'react';

const Termos = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Termos de Uso</h1>
          <p className="text-gray-600">Atualizado em: Janeiro de 2025</p>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg border border-gray-200 p-8">
          <div className="prose prose-lg max-w-none text-gray-700 space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">1. Aceitação dos Termos</h2>
              <p>
                Ao acessar e usar o site Cashback Brasil, você concorda em cumprir e estar vinculado 
                aos seguintes termos e condições de uso. Se você não concordar com qualquer parte 
                destes termos, não use nosso site.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">2. Uso do Conteúdo</h2>
              <p>
                O conteúdo deste site é fornecido apenas para fins informativos. As informações 
                são mantidas atualizadas e precisas, mas não garantimos que estarão sempre completas 
                ou isentas de erros.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">3. Propriedade Intelectual</h2>
              <p>
                Todo o conteúdo publicado neste site, incluindo textos, gráficos, logos, imagens e 
                software, é propriedade do Cashback Brasil ou de seus fornecedores de conteúdo e 
                está protegido por leis de direitos autorais.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">4. Links para Sites de Terceiros</h2>
              <p>
                Nosso site pode conter links para sites de terceiros. Não temos controle sobre o 
                conteúdo e práticas desses sites e não podemos aceitar responsabilidade por suas 
                respectivas políticas de privacidade.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">5. Comentários e Conteúdo do Usuário</h2>
              <p>Ao publicar comentários em nosso site, você concorda que:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Seu conteúdo não viola direitos autorais ou outros direitos de propriedade</li>
                <li>Seu conteúdo não contém material difamatório, ofensivo ou ilegal</li>
                <li>Reservamo-nos o direito de remover comentários inadequados</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">6. Publicidade</h2>
              <p>
                Este site exibe anúncios do Google AdSense. As empresas de publicidade podem usar 
                informações sobre suas visitas para fornecer anúncios relevantes.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">7. Limitação de Responsabilidade</h2>
              <p>
                Não seremos responsáveis por quaisquer perdas ou danos resultantes do uso deste site 
                ou da impossibilidade de usá-lo.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">8. Alterações nos Termos</h2>
              <p>
                Reservamo-nos o direito de modificar estes termos a qualquer momento. As alterações 
                entram em vigor imediatamente após a publicação no site.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">9. Contato</h2>
              <p>
                Se você tiver perguntas sobre estes Termos de Uso, entre em contato conosco 
                através do email: contato@cashbackbrasil.com
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Termos;