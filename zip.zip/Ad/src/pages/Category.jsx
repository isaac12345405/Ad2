import React from 'react';
import { useParams } from 'react-router-dom';
import { posts, categories } from '../mockData';
import PostCard from '../components/PostCard';
import Sidebar from '../components/Sidebar';

const Category = () => {
  const { slug } = useParams();
  const category = categories.find((c) => c.slug === slug);
  const categoryPosts = posts.filter((p) => p.category === slug);

  if (!category) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Categoria não encontrada</h1>
          <a href="/" className="text-emerald-600 hover:text-emerald-700">Voltar para home</a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">{category.name}</h1>
          <p className="text-xl text-gray-600">
            {categoryPosts.length} {categoryPosts.length === 1 ? 'artigo' : 'artigos'} nesta categoria
          </p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Posts */}
          <div className="lg:col-span-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {categoryPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Sidebar />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Category;