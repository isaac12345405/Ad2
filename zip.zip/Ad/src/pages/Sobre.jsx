import React from 'react';
import { Users, Target, Award } from 'lucide-react';

const Sobre = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Sobre Nós</h1>
          <p className="text-xl text-gray-600">
            Conheça a missão do Cashback Brasil
          </p>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg border border-gray-200 p-8 mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Quem Somos</h2>
          <div className="prose prose-lg max-w-none text-gray-700 space-y-4">
            <p>
              O <strong>Cashback Brasil</strong> é o seu guia completo para o mundo do cashback. 
              Nascemos com a missão de ajudar brasileiros a economizarem dinheiro em suas compras 
              do dia a dia, fornecendo informações claras, dicas práticas e análises detalhadas 
              sobre as melhores plataformas de cashback disponíveis no mercado.
            </p>
            <p>
              Acreditamos que todos merecem ter acesso a ferramentas que facilitem a economia 
              doméstica. Por isso, nosso conteúdo é desenvolvido por especialistas que testam e 
              avaliam cada serviço antes de recomendar aos nossos leitores.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Target className="w-8 h-8 text-emerald-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Nossa Missão</h3>
            <p className="text-gray-600">
              Educar e empoderar brasileiros a economizarem dinheiro através do cashback.
            </p>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-emerald-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Nossa Comunidade</h3>
            <p className="text-gray-600">
              Milhares de leitores que já economizaram usando nossas dicas e guias.
            </p>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-emerald-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Nossos Valores</h3>
            <p className="text-gray-600">
              Transparência, honestidade e compromisso com a qualidade da informação.
            </p>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">O Que Fazemos</h2>
          <ul className="space-y-3 text-gray-700">
            <li className="flex items-start">
              <span className="text-emerald-600 mr-2">✓</span>
              <span>Avaliamos e comparamos as principais plataformas de cashback do Brasil</span>
            </li>
            <li className="flex items-start">
              <span className="text-emerald-600 mr-2">✓</span>
              <span>Publicamos guias detalhados sobre como maximizar seus ganhos</span>
            </li>
            <li className="flex items-start">
              <span className="text-emerald-600 mr-2">✓</span>
              <span>Compartilhamos dicas e estratégias para economizar em compras</span>
            </li>
            <li className="flex items-start">
              <span className="text-emerald-600 mr-2">
✓</span>
              <span>Mantemos você atualizado sobre as melhores ofertas e promoções</span>
            </li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default Sobre;