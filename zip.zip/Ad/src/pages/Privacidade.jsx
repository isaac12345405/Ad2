import React from 'react';

const Privacidade = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Política de Privacidade</h1>
          <p className="text-gray-600">Atualizado em: Janeiro de 2025</p>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg border border-gray-200 p-8">
          <div className="prose prose-lg max-w-none text-gray-700 space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">1. Introdução</h2>
              <p>
                A sua privacidade é importante para nós. Esta Política de Privacidade explica como 
                o Cashback Brasil coleta, usa e protege suas informações pessoais quando você utiliza 
                nosso site.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">2. Informações que Coletamos</h2>
              <p>Podemos coletar as seguintes informações:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Nome e informações de contato, incluindo endereço de e-mail</li>
                <li>Informações demográficas</li>
                <li>Preferências e interesses</li>
                <li>Informações de uso do site através de cookies</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">3. Como Usamos suas Informações</h2>
              <p>Utilizamos suas informações para:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Melhorar nosso site e serviços</li>
                <li>Enviar newsletters e atualizações (com seu consentimento)</li>
                <li>Responder a suas perguntas e comentários</li>
                <li>Personalizar sua experiência no site</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">4. Cookies</h2>
              <p>
                Utilizamos cookies para melhorar a experiência do usuário. Cookies são pequenos 
                arquivos armazenados no seu dispositivo que nos ajudam a entender como você usa 
                nosso site.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">5. Google AdSense</h2>
              <p>
                Este site utiliza o Google AdSense para exibir anúncios. O Google pode usar cookies 
                para veicular anúncios com base nas suas visitas anteriores a este site ou a outros sites.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">6. Segurança</h2>
              <p>
                Estamos comprometidos em garantir que suas informações sejam seguras. Implementamos 
                medidas de segurança adequadas para prevenir acesso não autorizado ou divulgação.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">7. Seus Direitos</h2>
              <p>Você tem o direito de:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Solicitar uma cópia das informações que temos sobre você</li>
                <li>Solicitar correção de informações incorretas</li>
                <li>Solicitar a exclusão de suas informações</li>
                <li>Cancelar a inscrição de nossa newsletter a qualquer momento</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">8. Contato</h2>
              <p>
                Se você tiver dúvidas sobre esta Política de Privacidade, entre em contato conosco 
                através do email: contato@cashbackbrasil.com
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Privacidade;