import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { useToast } from '../hooks/use-toast';
import { subscribeNewsletter } from '../services/api';
import { Mail } from 'lucide-react';

const Sidebar = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSubscribe = async (e) => {
    e.preventDefault();
    if (email) {
      setLoading(true);
      try {
        await subscribeNewsletter(email);
        toast({
          title: 'Inscrição realizada!',
          description: 'Você receberá nossas novidades por email.',
        });
        setEmail('');
      } catch (error) {
        toast({
          title: 'Erro',
          description: error.response?.data?.detail || 'Não foi possível realizar a inscrição.',
          variant: 'destructive'
        });
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="space-y-8">
      {/* Newsletter */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Mail className="w-5 h-5 text-emerald-600" />
          <h3 className="text-lg font-bold text-gray-900">Newsletter</h3>
        </div>
        <p className="text-sm text-gray-600 mb-4">
          Receba as melhores dicas de cashback direto no seu email!
        </p>
        <form onSubmit={handleSubscribe} className="space-y-3">
          <Input
            type="email"
            placeholder="Seu melhor email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={loading}>
            {loading ? 'Inscrevendo...' : 'Inscrever-se'}
          </Button>
        </form>
      </div>

      {/* AdSense Placeholder 1 */}
      <div className="bg-gray-100 rounded-lg border border-gray-300 p-6">
        <div className="text-center text-gray-500">
          <p className="text-xs mb-2">PUBLICIDADE</p>
          <div className="bg-gray-200 h-64 flex items-center justify-center rounded">
            <span className="text-sm font-medium">Espaço AdSense 300x250</span>
          </div>
        </div>
      </div>

      {/* Categorias Populares */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Categorias</h3>
        <div className="space-y-2">
          <a href="/categoria/como-funciona" className="block py-2 px-3 bg-gray-50 rounded hover:bg-emerald-50 hover:text-emerald-700 transition-colors">
            Como Funciona
          </a>
          <a href="/categoria/melhores-apps" className="block py-2 px-3 bg-gray-50 rounded hover:bg-emerald-50 hover:text-emerald-700 transition-colors">
            Melhores Apps
          </a>
          <a href="/categoria/dicas" className="block py-2 px-3 bg-gray-50 rounded hover:bg-emerald-50 hover:text-emerald-700 transition-colors">
            Dicas
          </a>
        </div>
      </div>

      {/* AdSense Placeholder 2 */}
      <div className="bg-gray-100 rounded-lg border border-gray-300 p-6">
        <div className="text-center text-gray-500">
          <p className="text-xs mb-2">PUBLICIDADE</p>
          <div className="bg-gray-200 h-64 flex items-center justify-center rounded">
            <span className="text-sm font-medium">Espaço AdSense 300x250</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;