import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// ================= POSTS =================

export const getPosts = async () => {
  const response = await axios.get(`${API}/posts`);
  return response.data;
};

export const getPostBySlug = async (slug) => {
  const response = await axios.get(`${API}/posts/${slug}`);
  return response.data;
};

export const getPostsByCategory = async (categorySlug) => {
  const response = await axios.get(`${API}/posts/category/${categorySlug}`);
  return response.data;
};

export const createPost = async (postData) => {
  const response = await axios.post(`${API}/posts`, postData);
  return response.data;
};

export const updatePost = async (slug, postData) => {
  const response = await axios.put(`${API}/posts/${slug}`, postData);
  return response.data;
};

export const deletePost = async (slug) => {
  const response = await axios.delete(`${API}/posts/${slug}`);
  return response.data;
};

// ================= COMMENTS =================

export const getCommentsByPost = async (postId) => {
  const response = await axios.get(`${API}/comments/${postId}`);
  return response.data;
};

export const createComment = async (commentData) => {
  const response = await axios.post(`${API}/comments`, commentData);
  return response.data;
};

// ================= NEWSLETTER =================

export const subscribeNewsletter = async (email) => {
  const response = await axios.post(`${API}/newsletter`, { email });
  return response.data;
};

// ================= CONTACT =================

export const sendContact = async (contactData) => {
  const response = await axios.post(`${API}/contact`, contactData);
  return response.data;
};
