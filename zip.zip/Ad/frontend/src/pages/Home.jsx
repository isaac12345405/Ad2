import React, { useState, useEffect } from 'react';
import { getPosts } from '../services/api';
import PostCard from '../components/PostCard';
import Sidebar from '../components/Sidebar';

const Home = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const data = await getPosts();
        setPosts(data);
      } catch (error) {
        console.error('Erro ao buscar posts:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchPosts();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando posts...</p>
        </div>
      </div>
    );
  }

  const featuredPost = posts[0];
  const recentPosts = posts.slice(1);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Descubra o Mundo do Cashback
            </h1>
            <p className="text-xl text-gray-600">
              Aprenda a economizar dinheiro em todas as suas compras com as melhores dicas e guias sobre cashback
            </p>
          </div>
        </div>
      </section>

      {/* AdSense Banner - Top */}
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="bg-gray-100 rounded-lg border border-gray-300 p-4">
            <div className="text-center text-gray-500">
              <p className="text-xs mb-2">PUBLICIDADE</p>
              <div className="bg-gray-200 h-24 flex items-center justify-center rounded">
                <span className="text-sm font-medium">Espaço AdSense 728x90 (Leaderboard)</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Posts */}
          <div className="lg:col-span-2">
            {/* Featured Post */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Artigo em Destaque</h2>
              <article className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
                <a href={`/post/${featuredPost.slug}`}>
                  <img
                    src={featuredPost.image}
                    alt={featuredPost.title}
                    className="w-full h-96 object-cover"
                  />
                </a>
                <div className="p-8">
                  <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
                    <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full font-medium">
                      {featuredPost.categoryName}
                    </span>
                    <span>{new Date(featuredPost.date).toLocaleDateString('pt-BR')}</span>
                    <span>{featuredPost.readTime}</span>
                  </div>
                  <a href={`/post/${featuredPost.slug}`}>
                    <h3 className="text-3xl font-bold text-gray-900 mb-4 hover:text-emerald-600 transition-colors">
                      {featuredPost.title}
                    </h3>
                  </a>
                  <p className="text-gray-600 text-lg mb-6">{featuredPost.excerpt}</p>
                  <a
                    href={`/post/${featuredPost.slug}`}
                    className="inline-flex items-center text-emerald-600 font-semibold hover:text-emerald-700"
                  >
                    Ler artigo completo →
                  </a>
                </div>
              </article>
            </div>

            {/* Recent Posts */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Artigos Recentes</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {recentPosts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Sidebar />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;