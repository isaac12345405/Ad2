import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { getPostBySlug, getCommentsByPost, createComment } from '../services/api';
import Sidebar from '../components/Sidebar';
import { Button } from '../components/ui/button';
import { Textarea } from '../components/ui/textarea';
import { Input } from '../components/ui/input';
import { useToast } from '../hooks/use-toast';
import { Calendar, Clock, Tag, User } from 'lucide-react';

const PostDetail = () => {
  const { slug } = useParams();
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const [newComment, setNewComment] = useState({ name: '', email: '', content: '' });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const postData = await getPostBySlug(slug);
        setPost(postData);
        
        const commentsData = await getCommentsByPost(slug);
        setComments(commentsData);
      } catch (error) {
        console.error('Erro ao buscar dados:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando post...</p>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Post não encontrado</h1>
          <a href="/" className="text-emerald-600 hover:text-emerald-700">Voltar para home</a>
        </div>
      </div>
    );
  }

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    try {
      const comment = await createComment({
        postId: slug,
        author: newComment.name,
        email: newComment.email,
        content: newComment.content
      });
      setComments([...comments, comment]);
      setNewComment({ name: '', email: '', content: '' });
      toast({
        title: 'Comentário enviado!',
        description: 'Seu comentário foi publicado com sucesso.',
      });
    } catch (error) {
      console.error('Erro ao enviar comentário:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível enviar o comentário.',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* AdSense Banner - Top */}
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="bg-gray-100 rounded-lg border border-gray-300 p-4">
            <div className="text-center text-gray-500">
              <p className="text-xs mb-2">PUBLICIDADE</p>
              <div className="bg-gray-200 h-24 flex items-center justify-center rounded">
                <span className="text-sm font-medium">Espaço AdSense 728x90</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Post Content */}
          <article className="lg:col-span-2">
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <img
                src={post.image}
                alt={post.title}
                className="w-full h-96 object-cover"
              />
              <div className="p-8">
                {/* Meta */}
                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-6">
                  <span className="flex items-center space-x-1">
                    <Tag className="w-4 h-4" />
                    <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full font-medium">
                      {post.categoryName}
                    </span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(post.date).toLocaleDateString('pt-BR')}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{post.readTime}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <User className="w-4 h-4" />
                    <span>{post.author}</span>
                  </span>
                </div>

                {/* Title */}
                <h1 className="text-4xl font-bold text-gray-900 mb-6">{post.title}</h1>

                {/* Content */}
                <div
                  className="prose prose-lg max-w-none"
                  dangerouslySetInnerHTML={{ __html: post.content }}
                  style={{
                    lineHeight: '1.8',
                  }}
                />

                {/* AdSense In-Article */}
                <div className="my-8 bg-gray-100 rounded-lg border border-gray-300 p-4">
                  <div className="text-center text-gray-500">
                    <p className="text-xs mb-2">PUBLICIDADE</p>
                    <div className="bg-gray-200 h-32 flex items-center justify-center rounded">
                      <span className="text-sm font-medium">Espaço AdSense In-Article</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Comments Section */}
            <div className="bg-white rounded-lg border border-gray-200 p-8 mt-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Comentários ({comments.length})</h2>

              {/* Comment Form */}
              <form onSubmit={handleCommentSubmit} className="mb-8 p-6 bg-gray-50 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Deixe seu comentário</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      type="text"
                      placeholder="Seu nome"
                      value={newComment.name}
                      onChange={(e) => setNewComment({ ...newComment, name: e.target.value })}
                      required
                    />
                    <Input
                      type="email"
                      placeholder="Seu email"
                      value={newComment.email}
                      onChange={(e) => setNewComment({ ...newComment, email: e.target.value })}
                      required
                    />
                  </div>
                  <Textarea
                    placeholder="Escreva seu comentário..."
                    value={newComment.content}
                    onChange={(e) => setNewComment({ ...newComment, content: e.target.value })}
                    rows={4}
                    required
                  />
                  <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700">
                    Enviar Comentário
                  </Button>
                </div>
              </form>

              {/* Comments List */}
              <div className="space-y-6">
                {comments.map((comment) => (
                  <div key={comment.id} className="border-l-4 border-emerald-600 pl-4 py-2">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                        <User className="w-5 h-5 text-emerald-600" />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{comment.author}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(comment.date).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                    </div>
                    <p className="text-gray-700 ml-12">{comment.content}</p>
                  </div>
                ))}
              </div>
            </div>
          </article>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Sidebar />
          </div>
        </div>
      </section>
    </div>
  );
};

export default PostDetail;